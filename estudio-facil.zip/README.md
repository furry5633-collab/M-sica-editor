# 🎹 Estudio Fácil

Un estudio de música completo que funciona en el navegador. Sin instalar nada, sin cuentas, sin internet una vez cargado. Pensado para que cualquiera pueda hacer una canción aunque no sepa música.

**➡️ Probar: https://TU-USUARIO.github.io/estudio-facil/**

![Estudio Fácil](icon-512.png)

## Qué puedes hacer

- **🤖 Compositor automático** — Un botón y sale una canción entera: acordes, melodía, bajo y batería. No es azar: usa progresiones de acordes reales, coloca notas del acorde en los tiempos fuertes y repite un motivo, que es lo que hace que una melodía se recuerde.
- **🎨 47 estilos** — Pop, reggaetón, trap, lofi, house, techno, drum&bass, rock, balada, cumbia, salsa, bachata, afrobeat, dancehall, disco funk, jazz, 8 bits, cinemático, ambient, flamenco, samba, bossa nova, punk, metal, blues, country, k-pop, synthwave, gospel y muchos más.
- **🥁 Caja de ritmos** — 8 instrumentos, 40 ritmos precargados, swing y reverb.
- **🎵 Piano roll** — Teclas de piano reales que se iluminan al sonar. Modo "solo notas de la escala" para no desafinar nunca, o piano cromático completo.
- **🎹 Teclado tocable** — Con ratón, dedo o teclado del ordenador. Acordes de un clic.
- **🎤 Grabación de voz** — Tomas ilimitadas con reverb, eco, compresor, cambio de tono y distorsión. 6 presets (Estudio pro, Estadio, Radio vieja, Robot…).
- **🎛️ Mezclador** — Volumen, mute y solo por pista, más limitador de máster.
- **📚 Biblioteca + guardado automático** — Tus canciones se guardan solas. Si cierras la pestaña, al volver sigues donde lo dejaste.
- **💾 Exportar** — Descarga la canción terminada en WAV o WEBM, o el proyecto en JSON.

## Instalar como app

Se puede instalar en el móvil o el escritorio: abre la web y pulsa **📲 Instalar como app** (o "Añadir a pantalla de inicio" en el menú del navegador). Luego funciona **sin conexión**.

## Cómo está hecho

HTML, CSS y JavaScript puros. **Cero dependencias, cero build, cero backend.** Todo el sonido se genera en tiempo real con la Web Audio API — no hay ni un solo archivo de audio. Los datos se guardan en `localStorage`, así que nada sale de tu dispositivo.

| Archivo | Qué es |
|---|---|
| `index.html` | La aplicación entera (interfaz + motor de audio) |
| `sw.js` | Service worker, para que funcione sin internet |
| `manifest.webmanifest` | Permite instalarla como app |

## Ejecutar en local

```bash
python3 -m http.server 8080
```

Y abre `http://localhost:8080`. Hace falta un servidor (no basta abrir el archivo) porque el micrófono y el modo sin conexión lo requieren.

## Compatibilidad

Chrome, Edge, Firefox y Safari actualizados, en ordenador y móvil. Para grabar voz hacen falta permisos de micrófono y, recomendable, auriculares.

## Licencia

MIT — úsalo, modifícalo y compártelo libremente.
